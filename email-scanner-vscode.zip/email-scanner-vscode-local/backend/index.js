import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import Busboy from "busboy";
import fs from "fs";
import os from "os";
import path from "path";
import fetch from "node-fetch";
import { fileTypeFromFile } from "file-type";
import unzipper from "unzipper";
import NodeClam from "clamscan"; // npm 'clamscan'

const app = express();

// ── Security & basics
app.use(helmet());
app.use(cors({ origin: "http://localhost:5173" }));
app.use(express.json({ limit: "2mb" }));
app.use(rateLimit({ windowMs: 60_000, max: 60 }));

app.get("/health", (req, res) => res.json({ ok: true }));

// ===== ClamAV client =====
const clamPromise = (async () => {
  try {
    const clamscan = await new NodeClam().init({
      removeInfected: false,
      quarantineInfected: false,
      debugMode: false,
      preference: "clamdscan",
      clamdscan: {
        host: process.env.CLAMAV_HOST || "127.0.0.1",
        port: Number(process.env.CLAMAV_PORT || 3310),
        timeout: 120000, // 120s
        socket: false,
      },
    });
    console.log("✅ Connected to ClamAV daemon");
    return clamscan;
  } catch (e) {
    console.warn("⚠️  ClamAV unavailable, will fallback to heuristics only:", e.message);
    return null;
  }
})();

// ===== URL analysis (เดิม + probe) =====
const BRAND_ALLOW = [
  /(^|\.)google\.com$/i, /(^|\.)youtube\.com$/i, /(^|\.)microsoft\.com$/i,
  /(^|\.)facebook\.com$/i, /(^|\.)apple\.com$/i, /(^|\.)github\.com$/i
];
const FREE_HOST = /(wixsite|webnode|weebly|blogspot|000webhostapp|github\.io|notion\.site|carrd\.co)$/i;
const PHISH_WORDS = /(login|signin|verify|update|secure|account|bank|wallet|otp|password|reset|support|gift|bonus|prize)/i;

function clamp01(n){ return Math.max(0, Math.min(1, Number(n.toFixed(2)))); }

function finalize(score) {
  score = clamp01(score);
  let verdict = "clean", level = "ปลอดภัย";
  if (score >= 0.7) { verdict = "danger"; level = "เสี่ยงสูง"; }
  else if (score >= 0.35) { verdict = "suspicious"; level = "เฝ้าระวัง"; }
  const advice = (verdict === "clean")
    ? ["ยังไม่พบสัญญาณอันตรายชัดเจน", "หลีกเลี่ยงการกรอกข้อมูลส่วนตัวหากไม่มั่นใจ"]
    : ["อย่ากรอกรหัสผ่าน/OTP", "ตรวจสอบโดเมนให้ตรงกับองค์กรจริง", "ถ้ามาจากอีเมล ให้ตรวจผู้ส่ง/หัวอีเมล"];
  return { score, verdict, level, advice };
}

function scoreUrlStructure(u) {
  const issues = [];
  let s = 0;
  if (u.protocol !== "https:") { issues.push("ใช้ HTTP (ไม่เข้ารหัส)"); s += 0.35; }
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(u.hostname)) { issues.push("โดเมนเป็น IP address"); s += 0.3; }
  if (/^xn--/i.test(u.hostname)) { issues.push("โดเมนเป็น Punycode (เสี่ยงโดเมนเลียนแบบ)"); s += 0.25; }
  const digits = (u.hostname.match(/\d/g)||[]).length;
  const hyph = (u.hostname.match(/-/g)||[]).length;
  if (digits >= 4) { issues.push("โดเมนมีตัวเลขจำนวนมาก"); s += 0.15; }
  if (hyph >= 3)   { issues.push("โดเมนมีขีด (-) จำนวนมาก"); s += 0.15; }
  if (u.hostname.length > 30) { issues.push("โดเมนยาวผิดปกติ"); s += 0.15; }
  if (u.hostname.split(".").length - 1 >= 4) { issues.push("ซับโดเมนจำนวนมากผิดปกติ"); s += 0.2; }
  if (/\.(zip|mov|tk|ml|ga|cf|gq)$/i.test(u.hostname)) { issues.push("นามสกุลโดเมนที่พบการโจมตีบ่อย"); s += 0.2; }
  if (FREE_HOST.test(u.hostname)) { issues.push("โฮสต์ฟรี/เว็บสำเร็จรูป"); s += 0.2; }
  if (PHISH_WORDS.test(u.pathname + u.search)) { issues.push("พบบทความ/คำที่ชวนให้ล็อกอิน/ยืนยันตัวตน"); s += 0.25; }
  if (/@/.test(u.href)) { issues.push("พบสัญลักษณ์ @ ใน URL"); s += 0.15; }
  if (/\.\.\//.test(u.pathname)) { issues.push("รูปแบบ path น่าสงสัย (../)"); s += 0.15; }
  if (u.search && u.search.length > 150) { issues.push("พารามิเตอร์ URL ยาวมาก"); s += 0.1; }
  if (BRAND_ALLOW.some(rx => rx.test(u.hostname))) s = Math.max(0, s - 0.25);
  return { s, issues };
}

async function probePage(u) {
  let score = 0;
  const issues = [];
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), 4000);
  try {
    const res = await fetch(u.href, {
      method: "GET",
      redirect: "follow",
      headers: { "user-agent": "Mozilla/5.0 EmailScanner/1.1" },
      signal: controller.signal
    });
    const finalUrl = new URL(res.url || u.href);
    if (finalUrl.hostname !== u.hostname) {
      issues.push(`redirect ข้ามโดเมน → ${finalUrl.hostname}`);
      score += 0.25;
    }
    const html = await res.text().catch(() => "");
    if (/<form[^>]+(login|signin|password)/i.test(html)) { issues.push("พบฟอร์มเข้าสู่ระบบในหน้า"); score += 0.25; }
    if (/(otp|citizen.?id|บัตรประชาชน|พาสเวิร์ด)/i.test(html)) { issues.push("พบคำเกี่ยวกับ OTP/ข้อมูลอ่อนไหว"); score += 0.25; }
    if (/script[^>]+src=["']data:/i.test(html) || /(?:eval\(|atob\()/i.test(html)) {
      issues.push("ตรวจพบสคริปต์เข้ารหัส/อันตรายในหน้า");
      score += 0.2;
    }
  } catch {
    issues.push("โหลดหน้าไม่สำเร็จภายในเวลาที่กำหนด");
    score += 0.1;
  } finally { clearTimeout(t); }
  return { score, issues };
}

app.post("/api/scan/url", async (req, res) => {
  let { url } = req.body || {};
  if (!url) return res.status(400).json({ ok:false, error:"URL ว่าง" });
  if (!/^https?:\/\//i.test(url)) url = "https://" + url;

  let u; try { u = new URL(url); } catch { return res.status(400).json({ ok:false, error:"URL ไม่ถูกต้อง" }); }

  const s1 = scoreUrlStructure(u);
  const s2 = await probePage(u);
  const rawScore = s1.s + s2.score;
  const { score, verdict, level, advice } = finalize(rawScore);
  res.json({
    ok: true,
    kind: "url",
    target: u.href,
    score, verdict, level, advice,
    issues: [...s1.issues, ...s2.issues],
    engines: ["heuristic", "content-probe"]
  });
});

// ===== File scan (deep) =====
function basicHeuristics(meta, magic) {
  const issues = [];
  let s = 0;

  const name = (meta.filename || "").toLowerCase();
  const ext = path.extname(name).toLowerCase();

  // นามสกุลเสี่ยง
  if (/\.(exe|bat|cmd|scr|ps1|vbs|js|jar)$/i.test(name)) { issues.push("ไฟล์ที่สามารถรันโค้ดได้"); s += 0.7; }
  if (/\.(docm|xlsm|pptm)$/i.test(name)) { issues.push("ไฟล์ Office มีแมโคร"); s += 0.35; }
  if (/\.(zip|rar|7z)$/i.test(name)) { issues.push("ไฟล์บีบอัด อาจซ่อนมัลแวร์"); s += 0.25; }
  if (/\.(pdf)$/i.test(name)) { s += 0.05; }

  // ขนาดใหญ่มาก
  if ((meta.size || 0) > 25 * 1024 * 1024) { issues.push("ไฟล์ขนาดใหญ่มาก"); s += 0.15; }

  // magic bytes ไม่ตรงกับนามสกุล
  if (magic?.ext && ext && magic.ext !== ext.replace(/^\./, "")) {
    issues.push(`ชนิดจริงของไฟล์ (${magic.ext}) ไม่ตรงกับนามสกุล (${ext})`);
    s += 0.25;
  }
  return { s, issues };
}

async function scanWithClam(filePath) {
  const clam = await clamPromise;
  if (!clam) return { available:false };
  const { isInfected, viruses } = await clam.scanFile(filePath);
  return {
    available: true,
    isInfected: Boolean(isInfected),
    viruses: viruses || []
  };
}

// แตก zip และตรวจรายชื่อไฟล์ด้านใน (แบบรวดเร็ว)
async function peekZipList(filePath, limit = 50) {
  try {
    const entries = [];
    const dir = await unzipper.Open.file(filePath);
    for (const e of dir.files.slice(0, limit)) {
      entries.push(e.path);
    }
    return { ok:true, entries };
  } catch {
    return { ok:false, entries:[] };
  }
}

app.post("/api/scan/file", async (req, res) => {
  try {
    const bb = Busboy({ headers: req.headers, limits: { fileSize: 100 * 1024 * 1024 } }); // 100MB
    let tmp = "", meta = { filename:"uploaded.bin", size:0 };

    bb.on("file", (name, file, info) => {
      meta.filename = info.filename || meta.filename;
      tmp = path.join(os.tmpdir(), `${Date.now()}_${meta.filename}`);
      const ws = fs.createWriteStream(tmp);
      file.on("data", c => meta.size += c.length);
      file.pipe(ws);
      ws.on("close", async () => {
        try {
          // 1) ตรวจ magic bytes
          const magic = await fileTypeFromFile(tmp).catch(() => null);

          // 2) heuristic เบื้องต้น
          const h = basicHeuristics(meta, magic);

          // 3) ถ้าเป็น zip → peek โครงสร้าง
          let zipPeek = null;
          if (/\.(zip)$/i.test(meta.filename)) {
            zipPeek = await peekZipList(tmp);
            if (zipPeek.ok && zipPeek.entries.some(p => /\.(exe|bat|cmd|scr|ps1|vbs|js|jar)$/i.test(p))) {
              h.s += 0.35;
              h.issues.push("ZIP ภายในมีไฟล์ที่รันโค้ดได้");
            }
          }

          // 4) ส่งให้ ClamAV สแกนจริง
          const clam = await scanWithClam(tmp);
          let clamScore = 0;
          const issues = [...h.issues];

          if (clam.available) {
            if (clam.isInfected) {
              clamScore = 1.0;
              issues.push(`ClamAV ตรวจพบไวรัส: ${clam.viruses.join(", ")}`);
            } else {
              issues.push("ClamAV: ไม่พบมัลแวร์ที่รู้จัก");
            }
          } else {
            issues.push("ClamAV: ไม่พร้อมใช้งาน (ใช้เฉพาะ heuristics)");
          }

          const rawScore = h.s + clamScore;
          const { score, verdict, level, advice } = finalize(rawScore);

          res.json({
            ok:true,
            kind:"file",
            filename: meta.filename,
            size: meta.size,
            mime: magic?.mime || "unknown",
            score, verdict, level, advice,
            issues,
            engines: ["heuristic", clam.available ? "clamav" : "no-clamav"]
          });
        } catch (err) {
          res.status(500).json({ ok:false, error:String(err) });
        } finally {
          if (tmp) fs.rm(tmp, { force:true }, () => {});
        }
      });
    });

    bb.on("error", err => {
      res.status(400).json({ ok:false, error:String(err) });
      if (tmp) fs.rm(tmp, { force:true }, () => {});
    });

    req.pipe(bb);
  } catch (e) {
    res.status(500).json({ ok:false, error:String(e) });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Backend running on http://localhost:${PORT}`));
