from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import yara, os, tempfile, hashlib, io, re, urllib.parse as up, idna, subprocess, shlex
import clamd

YARA_DIR = os.path.join(os.path.dirname(__file__), "..", "rules")
YARA_DIR = os.path.abspath(YARA_DIR)
RULES = yara.compile(filepath=os.path.join(YARA_DIR, "bundle.yar"))

app = FastAPI()

def av_scan_bytes(data: bytes):
    mode = os.getenv("CLAM_MODE", "daemon")
    if mode == "off":
        return {"skipped": True}
    if mode == "daemon":
        host = os.getenv("CLAMAV_HOST", "127.0.0.1")
        port = int(os.getenv("CLAMAV_PORT", "3310"))
        cd = clamd.ClamdNetworkSocket(host=host, port=port)
        try:
            res = cd.instream(io.BytesIO(data))
            status, sig = res.get('stream', ('OK', None))
            infected = (status == 'FOUND')
            return {"infected": infected, "signature": sig, "mode": "daemon"}
        except Exception as e:
            return {"infected": False, "error": f"clamd-error:{e}", "mode": "daemon"}
    # CLI fallback
    fd, path = tempfile.mkstemp(prefix="cli_", dir="/tmp")
    with os.fdopen(fd, "wb") as f:
        f.write(data)
    try:
        cmd = "clamscan --no-summary " + shlex.quote(path)
        p = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        infected = "OK" not in p.stdout
        sig = None
        if infected and ":" in p.stdout:
            sig = p.stdout.strip().split(":")[-1].strip()
        return {"infected": infected, "signature": sig, "mode": "cli"}
    finally:
        try: os.remove(path)
        except: pass

def analyze_url(url: str):
    verdicts = []
    try:
        parsed = up.urlparse(url)
        host = parsed.hostname or ""
        try:
            decoded = idna.decode(host.encode("ascii").decode())
        except Exception:
            decoded = host
        if host != decoded:
            verdicts.append("punycode-domain")
        if re.search(r"(paypa1|faceb00k|micr0soft|security\-alert|login\-verify)", host):
            verdicts.append("lookalike-domain")
    except Exception as e:
        verdicts.append(f"parse-error:{e}")
    return {"url": url, "flags": verdicts}

class UrlIn(BaseModel):
    url: str

@app.post("/scan/file")
async def scan_file(request: Request):
    data = await request.body()
    if not data or len(data) > 25 * 1024 * 1024:
        raise HTTPException(400, "Invalid size")
    sha256 = hashlib.sha256(data).hexdigest()
    ymatches = [m.rule for m in RULES.match(data=data)]
    av = av_scan_bytes(data)
    verdict = "malicious" if (av.get("infected") or ymatches) else "clean"
    report = {
        "sha256": sha256,
        "yara_matches": ymatches,
        "clamav": av,
        "verdict": verdict,
        "kept_seconds": 0
    }
    return JSONResponse(report)

@app.post("/scan/url")
async def scan_url(body: UrlIn):
    info = analyze_url(body.url)
    verdict = "suspicious" if info["flags"] else "clean"
    return JSONResponse({"url": info["url"], "flags": info["flags"], "verdict": verdict})

@app.get("/healthz")
async def healthz():
    return {"ok": True}
